/*
 * $Id$
 *
 * Copyright Princeton eCom, Inc. 2006.  All rights reserved.
 * This source code file contains the proprietary and confidential information 
 * and trade secrets of Princeton eCom, Inc.
 */

package com.princetonecom.rtds.billerfinder;



import java.sql.Timestamp;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;



/**
 * Singleton class to perform incoming biller id to pecom id match. The class
 * loads data from rtds_biller table into member attributes and uses it
 * during match The ids are stored in List as BillerBusinessId is unique in
 * rtds_biller table
 * 
 * @version $Revision$
 */
public class PeComBillerIdMapper {
  protected static final int BILLER_ID_INITIAL_CAPACITY = 1;
  protected static final String ERROR_SELECT_MODIFIED_DTM = "Error Retrieving last Modified Date and Time. Unable to Refresh the Biller Cache";

 

  /** Singleton Instance */
  protected static PeComBillerIdMapper _obj;

  /** The highest modified timestamp of all rows in the cache. */
  protected Timestamp _mostRecentUpdateInCache = null;

  /** Data structure to hold PeCom's biller business ids */
  protected Map _peComBillerMap;

  /**
   * protected constructor for Singleton access. The member attributes are
   * initialized as part of object creation.
   */
  protected PeComBillerIdMapper()
  {
    // Intentionally blank
  }

  /**
   * Method to get single instance of this class
   * 
   * @return instance of this class
   */
  public static PeComBillerIdMapper getInstance()
  {
    if (_obj == null)
    {
      _create();
    }

    return _obj;
  }


  


  /**
   * Finds a matching biller matching incoming biller id
   * 
   * @param billerId
   * @return matching biller business id in the collection
   */
  public Set findBillerIdMatch(long billerId)
  {
    Set idList = new HashSet(PeComBillerIdMapper.BILLER_ID_INITIAL_CAPACITY);
    Map peComBillerMap = null;
    Long billerIdObj = null;


    synchronized (this)
    {
      peComBillerMap = _peComBillerMap;
    }

    if (peComBillerMap != null)
    {
      // search in the collection
      billerIdObj = new Long(billerId);

      if (peComBillerMap.containsKey(billerIdObj))
      {
        idList.add(billerIdObj);
      }
    }

    return idList;
  }


  /**
   * Synchronized method to create an instance of this class
   */
  protected static synchronized void _create()
  {
    if (_obj == null)
    {
      _obj = new PeComBillerIdMapper();
    }
  }


  
}