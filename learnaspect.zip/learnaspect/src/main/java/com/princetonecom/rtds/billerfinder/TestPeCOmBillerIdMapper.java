package com.princetonecom.rtds.billerfinder;

public class TestPeCOmBillerIdMapper {
	
	public static void main(String s[]){
		
		PeComBillerIdMapper peComBillerIdMapper = PeComBillerIdMapper.getInstance();
		
		peComBillerIdMapper.findBillerIdMatch(1000L);
		
	}

}
