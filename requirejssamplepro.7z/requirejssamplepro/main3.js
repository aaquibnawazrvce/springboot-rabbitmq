define(function (require) {
   
   var calObj = require('./calculator1');
   calObj.number1=10;
   calObj.number2=20;
   calObj.doFun();
   
   alert("Welcome to Calculator Results");
   document.write("Addition Result = "+calObj.addResult +"<br>  Subtraction Results = "+calObj.subResult);
});