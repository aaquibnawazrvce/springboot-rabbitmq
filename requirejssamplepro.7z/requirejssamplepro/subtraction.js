define({
	
	a:0,
	b:0,
	sub: function (){
		return this.a-this.b;
	}
})