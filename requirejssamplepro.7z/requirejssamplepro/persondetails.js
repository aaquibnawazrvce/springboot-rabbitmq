define(function () {
 
	return {
			name:"Aaquib",
			city:"Bangalore",
			state:"Karntaka",
			country:"India"
	}

});	