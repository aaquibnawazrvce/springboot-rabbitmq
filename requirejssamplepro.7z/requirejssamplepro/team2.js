define({
	
	team:"Royal Challengers",
	captain:"Kohli"
	
})