define({
	
	a:0,
	b:0,
	add: function (){
		return this.a+this.b;
	}
})