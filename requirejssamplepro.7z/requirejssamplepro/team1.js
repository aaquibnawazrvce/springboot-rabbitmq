define({
	
	team:"Hyberabad Nawabs",
	captain:"Kumar"
	
})