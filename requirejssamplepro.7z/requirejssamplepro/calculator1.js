define(['./addition','./subtraction'],function (addition,subtraction) {
 
	return {
			"hello":"Hi How are you",
			number1:0,
			number2:0,
			addResult:0,
			subResult:0,
			doFun:function(){
				
				addition.a=this.number1;
				addition.b=this.number2;
					addition.a=this.number1;
			addition.b=this.number2;
			
			subtraction.a=this.number1;
			subtraction.b=this.number2;
			
			this.addResult= addition.add();
			this.subResult=subtraction.sub();
				
			}
		
			
		}
		
		
	

});	