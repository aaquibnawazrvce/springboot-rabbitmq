define(function (require) {
   var person = require("./persondetails");
   alert("Welcome to Person Details");
   document.write("<h4>Persosn Details: </h4>" + "<br>" + " Name:"+person.name +"<br>City:"+person.city +"<br>"+"<br>State:"+person.state +"<br>"+"<br>Country:"+person.country +"<br>");   
});